import logging
import jwt
from jwt import ExpiredSignatureError, InvalidTokenError
from fastapi import Request, HTTPException
from .functions import JWT_SECRET_KEY

log = logging.getLogger("user_auth.jwt")


async def token_required(request: Request) -> dict:
    """
    FastAPI-compatible Depends() dependency.
    Reads 'x-access-token' from request headers, verifies it,
    and returns the decoded payload.
    Never generates a new token — only validates.
    """
    token = request.headers.get("x-access-token")
    log.debug("x-access-token present: %s", bool(token))

    if not token:
        raise HTTPException(status_code=401, detail={"error": "Token is missing!"})

    try:
        data = jwt.decode(token, JWT_SECRET_KEY, algorithms=["HS256"])
        log.debug("Token verified for: %s", data.get("email", "unknown"))
        return data

    except ExpiredSignatureError:
        raise HTTPException(status_code=401, detail={"error": "Token has expired!"})

    except InvalidTokenError as e:
        raise HTTPException(status_code=401, detail={"error": f"Token is invalid: {str(e)}"})



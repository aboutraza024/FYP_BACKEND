from __future__ import annotations

import asyncio
import logging
import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Optional

import uvicorn
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, field_validator
from fastapi.middleware.cors import CORSMiddleware
from audio import voice_to_hadith_query
from image import extract_hadith_from_image
from utils import generate_response

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("hadith_api")

# ── Config ────────────────────────────────────────────────────────────────────
UPLOAD_AUDIO_DIR  = os.getenv("UPLOAD_AUDIO_DIR", "uploads")
UPLOAD_IMAGE_DIR  = os.getenv("UPLOAD_IMAGE_DIR", "upload_image")
MAX_AUDIO_MB      = int(os.getenv("MAX_AUDIO_MB", "25"))
MAX_IMAGE_MB      = int(os.getenv("MAX_IMAGE_MB", "10"))
MAX_AUDIO_BYTES   = MAX_AUDIO_MB * 1024 * 1024
MAX_IMAGE_BYTES   = MAX_IMAGE_MB * 1024 * 1024

ALLOWED_AUDIO_EXT = {".mp3", ".mp4", ".wav", ".webm", ".m4a", ".ogg", ".flac"}
ALLOWED_IMAGE_EXT = {".jpg", ".jpeg", ".jfif", ".png", ".gif", ".webp"}

os.makedirs(UPLOAD_AUDIO_DIR, exist_ok=True)
os.makedirs(UPLOAD_IMAGE_DIR, exist_ok=True)


# ── Lifespan ──────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 Hadith API starting up...")
    yield
    log.info("🛑 Hadith API shutting down...")
    try:
        from utils import _http_session
        if _http_session and not _http_session.closed:
            await _http_session.close()
            log.info("✅ aiohttp session closed.")
    except Exception:
        pass


app = FastAPI(title="Hadith Chat API", version="2.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],        # local mein "*" theek hai
    allow_credentials=True,
    allow_methods=["*"],        # GET, POST, OPTIONS sab
    allow_headers=["*"],        # Content-Type, Authorization sab
)
# ── Global exception handlers ─────────────────────────────────────────────────
@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    log.warning("Validation error on %s: %s", request.url.path, exc.errors())
    return JSONResponse(
        status_code=422,
        content={"success": False, "error": "Invalid request data.", "details": exc.errors()},
    )


@app.exception_handler(Exception)
async def generic_error_handler(request: Request, exc: Exception):
    log.exception("Unhandled exception on %s", request.url.path)
    return JSONResponse(
        status_code=500,
        content={"success": False, "error": "Internal server error. Please try again later."},
    )


# ── Models ────────────────────────────────────────────────────────────────────
class ChatRequest(BaseModel):
    query       : str
    book_filter : Optional[str] = None

    @field_validator("query")
    @classmethod
    def query_not_empty(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Query cannot be empty.")
        if len(v) > 2000:
            raise ValueError("Query too long (max 2000 characters).")
        return v

    @field_validator("book_filter", mode="before")
    @classmethod
    def strip_book_filter(cls, v):
        if isinstance(v, str):
            v = v.strip()
            return v if v else None
        return v


# ── Helpers ───────────────────────────────────────────────────────────────────
def _ext(filename: str) -> str:
    return os.path.splitext(filename or "")[1].lower()


async def _read_upload(file: UploadFile, max_bytes: int, allowed_ext: set[str]) -> bytes:
    """
    Read upload into memory with size + extension validation.
    Returns raw_bytes — raises HTTPException on any problem.
    """
    ext = _ext(file.filename)
    if ext not in allowed_ext:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{ext}'. Allowed: {', '.join(sorted(allowed_ext))}",
        )

    try:
        content = await file.read()
    except Exception as exc:
        log.error("Failed to read uploaded file: %s", exc)
        raise HTTPException(status_code=400, detail="Could not read uploaded file.")

    if len(content) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    if len(content) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"File too large. Max allowed: {max_bytes // (1024*1024)} MB.",
        )

    return content


def _write_temp(content: bytes, filename: str, upload_dir: str) -> str:
    safe_name = f"{uuid.uuid4()}_{os.path.basename(filename or 'upload')}"
    path      = os.path.join(upload_dir, safe_name)
    try:
        with open(path, "wb") as f:
            f.write(content)
    except OSError as exc:
        log.error("Failed to write temp file %s: %s", path, exc)
        raise HTTPException(status_code=500, detail="Could not save uploaded file.")
    return path


def _cleanup(path: str) -> None:
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception as exc:
        log.warning("Could not delete temp file %s: %s", path, exc)


# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/")
async def root():
    return {"status": "ok", "message": "Hadith Chat API is running!"}


@app.get("/health")
async def health():
    """Lightweight liveness probe."""
    return {"status": "healthy"}


@app.post("/chat")
async def chat(request: ChatRequest):
    query       = request.query        # already stripped + validated by pydantic
    book_filter = request.book_filter  # None means search all books
    start       = time.perf_counter()

    log.info("📥 /chat | book_filter=%s | query=%.80s", book_filter or "all", query)

    try:
        result = await asyncio.wait_for(
            generate_response(query, book_filter=book_filter),
            timeout=120,
        )
    except asyncio.TimeoutError:
        log.error("generate_response timed out for query: %.80s", query)
        raise HTTPException(status_code=504, detail="Request timed out. Please try again.")
    except Exception as exc:
        log.exception("generate_response failed: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to generate response.")

    if not result:
        raise HTTPException(status_code=500, detail="Empty response from model.")

    return {
        "success"            : True,
        "query"              : query,
        "book_filter"        : book_filter,
        "response"           : result,
        "time_taken_seconds" : round(time.perf_counter() - start, 2),
    }


@app.post("/voice-to-hadith")
async def voice_to_hadith(
    file        : UploadFile    = File(...),
    user_text   : Optional[str] = Form(None),
    book_filter : Optional[str] = Form(None),
):
    start       = time.perf_counter()
    file_path   = None
    book_filter = book_filter.strip() if book_filter and book_filter.strip() else None

    log.info("📥 /voice-to-hadith | book_filter=%s", book_filter or "all")

    content   = await _read_upload(file, MAX_AUDIO_BYTES, ALLOWED_AUDIO_EXT)
    file_path = _write_temp(content, file.filename, UPLOAD_AUDIO_DIR)

    try:
        loop = asyncio.get_event_loop()

        try:
            voice_result = await asyncio.wait_for(
                loop.run_in_executor(None, voice_to_hadith_query, file_path),
                timeout=60,
            )
        except asyncio.TimeoutError:
            raise HTTPException(status_code=504, detail="Audio transcription timed out.")
        except Exception as exc:
            log.error("Transcription error: %s", exc)
            raise HTTPException(status_code=502, detail=f"Transcription failed: {exc}")

        voice_text = (voice_result.get("transcribed_text") or "").strip()
        if not voice_text:
            raise HTTPException(status_code=422, detail="Could not transcribe audio. Please speak clearly.")

        ut             = (user_text or "").strip()
        combined_query = (
            f"User Text: {ut}\nVoice Text: {voice_text}" if ut else voice_text
        )

        try:
            result = await asyncio.wait_for(
                generate_response(combined_query, book_filter=book_filter),
                timeout=120,
            )
        except asyncio.TimeoutError:
            raise HTTPException(status_code=504, detail="Response generation timed out.")
        except Exception as exc:
            log.exception("generate_response failed in voice route: %s", exc)
            raise HTTPException(status_code=500, detail="Failed to generate response.")

        return {
            "success"           : True,
            "book_filter"       : book_filter,
            "response"          : result,
            "time_taken_seconds": round(time.perf_counter() - start, 2),
        }

    finally:
        _cleanup(file_path)


@app.post("/image-to-hadith")
async def image_to_hadith(
    file        : UploadFile    = File(...),
    user_text   : Optional[str] = Form(None),
    book_filter : Optional[str] = Form(None),
):
    start       = time.perf_counter()
    file_path   = None
    book_filter = book_filter.strip() if book_filter and book_filter.strip() else None

    log.info("📥 /image-to-hadith | book_filter=%s", book_filter or "all")

    content   = await _read_upload(file, MAX_IMAGE_BYTES, ALLOWED_IMAGE_EXT)
    file_path = _write_temp(content, file.filename, UPLOAD_IMAGE_DIR)

    try:
        loop = asyncio.get_event_loop()

        try:
            result = await asyncio.wait_for(
                loop.run_in_executor(None, extract_hadith_from_image, file_path),
                timeout=60,
            )
        except asyncio.TimeoutError:
            raise HTTPException(status_code=504, detail="Image processing timed out.")
        except Exception as exc:
            log.error("Image extraction error: %s", exc)
            raise HTTPException(status_code=502, detail=f"Image processing failed: {exc}")

        if not result.get("is_hadith_related"):
            return {
                "success": False,
                "message": "Image mein koi Hadith content detect nahi hua.",
            }

        optimized_query = (result.get("optimized_query") or "").strip()
        if not optimized_query:
            raise HTTPException(status_code=422, detail="Could not extract a valid query from image.")

        ut             = (user_text or "").strip()
        combined_query = f"{ut}\n{optimized_query}" if ut else optimized_query

        try:
            response = await asyncio.wait_for(
                generate_response(combined_query, book_filter=book_filter),
                timeout=120,
            )
        except asyncio.TimeoutError:
            raise HTTPException(status_code=504, detail="Response generation timed out.")
        except Exception as exc:
            log.exception("generate_response failed in image route: %s", exc)
            raise HTTPException(status_code=500, detail="Failed to generate response.")

        return {
            "success"           : True,
            "book_filter"       : book_filter,
            "response"          : response,
            "time_taken_seconds": round(time.perf_counter() - start, 2),
        }

    finally:
        _cleanup(file_path)


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host      = "127.0.0.1",
        port      = 8000,
        reload    = True,
        workers   = 1,
        log_level = "info",
    )